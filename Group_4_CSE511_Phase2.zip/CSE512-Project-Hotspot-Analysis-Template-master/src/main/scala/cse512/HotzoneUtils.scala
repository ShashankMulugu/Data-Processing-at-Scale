package cse512

object HotzoneUtils {
/*
Method: ST_Contains
Input: pointString:String, queryRectangle:String
Output: Boolean (true or false)
*/
  def ST_Contains(queryRectangle: String, pointString: String ): Boolean = {
    var rect = new Array[String](4)
    rect = queryRectangle.split(",")
    var rect_a1 = rect(0).trim.toDouble
    var rect_b1 = rect(1).trim.toDouble
    var rect_a2 = rect(2).trim.toDouble
    var rect_b2 = rect(3).trim.toDouble

    var point = new Array[String](2)
    point = pointString.split(",")
    var pt_x=point(0).trim.toDouble
    var pt_y=point(1).trim.toDouble

    var lx =0.0
    var hx =0.0

    if (rect_a1 < rect_a2) {
      lx = rect_a1
      hx = rect_a2
    }

    else {
      lx = rect_a2
      hx = rect_a1
    }

    var ly = math.min(rect_b1, rect_b2)
    var hy = math.max(rect_b1, rect_b2)

    if(pt_y > hy || pt_x < lx || pt_x > hx || pt_y < ly)
      return false

    else
      return true
  }
}
